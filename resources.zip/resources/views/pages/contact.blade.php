@extends('app')

@section('content')

<h1> Contact Me!</h1>

@stop

@section('footer')

<script>alert('alert from contact');</script>

@stop